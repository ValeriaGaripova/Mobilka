package com.example.project_m;

public class Constants {
    public static final String PREFS_NAME = "user_prefs";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_IS_LOGGED_IN = "is_logged_in";
    public static final String KEY_CURRENT_USER = "current_user";
    
}